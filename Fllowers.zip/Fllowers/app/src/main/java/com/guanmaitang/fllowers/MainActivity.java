package com.guanmaitang.fllowers;

import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.RelativeLayout;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.animation.GlideAnimation;
import com.bumptech.glide.request.target.SimpleTarget;

public class MainActivity extends AppCompatActivity {

    private Button btn_start;
    // 撒花特效
    private RelativeLayout rlt_animation_layout;
    private FllowerAnimation fllowerAnimation;
    private Bitmap myBitmap;
    private FllowerAnimation fllowerAnimation1;
    private FllowerAnimation fllowerAnimation2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // 撒花初始化
        rlt_animation_layout = findViewById(R.id.rlt_animation_layout);
        rlt_animation_layout.setVisibility(View.VISIBLE);

        Glide.with(MainActivity.this)
                .load("http://pic.qiantucdn.com/58pic/14/08/12/55z58PIChMP_1024.jpg")
                .asBitmap()
                .into(new SimpleTarget<Bitmap>(100, 100) {
                    @Override
                    public void onResourceReady(Bitmap resource, GlideAnimation<? super Bitmap> glideAnimation) {
                        Log.i("liu111", "run: " + resource.getHeight());
                        fllowerAnimation = new FllowerAnimation(MainActivity.this, resource);
                        RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(
                                RelativeLayout.LayoutParams.MATCH_PARENT,
                                RelativeLayout.LayoutParams.MATCH_PARENT);
                        fllowerAnimation.setLayoutParams(params);

                        fllowerAnimation1 = new FllowerAnimation(MainActivity.this, resource);
                        fllowerAnimation.setLayoutParams(params);

                        fllowerAnimation2 = new FllowerAnimation(MainActivity.this, resource);
                        fllowerAnimation.setLayoutParams(params);

                        rlt_animation_layout.addView(fllowerAnimation);
                        fllowerAnimation.startAnimation();

                        new Handler().postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                rlt_animation_layout.addView(fllowerAnimation1);
                                fllowerAnimation1.startAnimation();
                            }
                        }, 1000);

                        new Handler().postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                rlt_animation_layout.addView(fllowerAnimation2);
                                fllowerAnimation2.startAnimation();
                            }
                        }, 2000);
                    }
                });
    }
}
